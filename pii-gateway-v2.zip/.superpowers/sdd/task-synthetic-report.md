# Task Report: Synthetic Masking Mode Backend

**Status:** DONE
**Commit:** `1369f18` feat: synthetic masking mode backend
**Date:** 2026-09-23

## Summary

Implemented the backend for the `synthetic` masking mode per the spec
`docs/superpowers/specs/2026-09-23-synthetic-masking-design.md` (sections 1–3).

## Changes

### 1. `internal/masker/synthetic.go` (new)

Added `Synthetic(text string, spans []detector.Span) string` that replaces each
span with a realistic synthetic value based on its type. Spans are processed
left-to-right by building a new string (same approach as `masker.Mask`), so byte
offsets remain valid.

Synthetic values per type:
- ФИО / ДЕРЖАТЕЛЬ → random Russian name (`Петров Пётр Петрович`)
- ТЕЛЕФОН → `+7 900 000-00-00`
- EMAIL → `user123@example.com`
- КАРТА → valid Luhn 16-digit number (check digit computed)
- ПАСПОРТ / ВУ / ЗАГРАНПАСПОРТ / ВОЕННЫЙ_БИЛЕТ / СВИДЕТЕЛЬСТВО_О_РОЖДЕНИИ → random series + number
- ИНН → random 10/12 digits
- ДАТА / ДАТА_РОЖДЕНИЯ → random date `dd.mm.yyyy`
- CVV → random 3 digits
- ПИН → random 4 digits
- АДРЕС → random street + city
- fallback → `[TYPE]` placeholder via `s.Type.Placeholder()`

**Determinism:** each span's synthetic value is derived from an FNV-1a hash of
the span's original text, used to seed a fresh `math/rand.New(rand.NewSource(seed))`.
Same input → same output, keeping the benchmark retry logic in `process.go`
working. No global `math/rand` is used.

### 2. `internal/pipeline/pipeline.go`

Added a `synthetic` branch in `Process()`:
```go
if p.opts.Mode == "token" {
    masked, tokens = masker.Tokenize(text, kept)
} else if p.opts.Mode == "synthetic" {
    masked = masker.Synthetic(text, kept)
} else {
    masked = masker.Mask(text, kept)
}
```

### 3. `internal/config/config.go`

Updated the `SystemConfig.Masking` field comment to document the third mode:
`"redact" | "token" | "synthetic"`.

## Tests

- `internal/masker/synthetic_test.go` (new): each type produces a synthetic value
  (not original, not placeholder); phone-like output; 16-digit Luhn-valid card;
  date-like output; determinism (same input → same output); fallback placeholder;
  no-spans passthrough.
- `internal/pipeline/pipeline_test.go`: added `TestPipelineSyntheticMode` verifying
  synthetic output (no placeholders) for `Mode: "synthetic"`.

## Verification

- `go test ./internal/masker/ ./internal/pipeline/` — PASS
- `go test ./...` — PASS (all packages)
- `go vet ./internal/masker/ ./internal/pipeline/ ./internal/config/` — clean
- `gofmt` — my new/edited files are formatted.

## Concerns

- Phone and email synthetic values are constants (`+7 900 000-00-00`,
  `user123@example.com`) per the spec table, so they are identical across all
  spans of that type. This is spec-compliant; determinism still holds.
- Pre-existing files `internal/masker/masker.go`, `token.go`, and their tests are
  not gofmt-clean in the repo. I did not touch them (out of scope for this task).