### Task 4: Config for queue, store circuit, autoscale

**Files:**
- Modify: `internal/config/config.go`
- Test: `internal/config/config_test.go`

**Interfaces:**
- Consumes: существующий `config.Config`.
- Produces:
  - `type QueueConfig struct { Workers int; FastCapacity int; HeavyCapacity int; HeavyThreshold int }`
  - `type CircuitConfig struct { Failures int; CooldownSeconds int }`
  - `type AutoscaleConfig struct { MinReplicas int; MaxReplicas int; CPUUp int; CPUDown int; QueueUp int; LatencyP99MS int; CooldownSeconds int; PollSeconds int }`
  - Поля в `Config`: `Queue QueueConfig`, `Store.Circuit CircuitConfig`, `Autoscale AutoscaleConfig`.

- [ ] **Step 1: Write the failing test**

```go
package config

import (
	"os"
	"path/filepath"
	"testing"

	"github.com/stretchr/testify/require"
)

func TestLoadQueueAndAutoscale(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "config.yaml")
	content := `
queue:
  workers: 8
  fast_capacity: 512
  heavy_capacity: 128
  heavy_threshold: 4096
store:
  type: layered
  circuit:
    failures: 5
    cooldown_seconds: 5
autoscale:
  min_replicas: 2
  max_replicas: 20
  cpu_up: 70
  cpu_down: 30
  queue_up: 100
  latency_p99_ms: 100
  cooldown_seconds: 30
  poll_seconds: 10
`
	require.NoError(t, os.WriteFile(path, []byte(content), 0o644))
	cfg, err := Load(path)
	require.NoError(t, err)
	require.Equal(t, 8, cfg.Queue.Workers)
	require.Equal(t, 512, cfg.Queue.FastCapacity)
	require.Equal(t, 128, cfg.Queue.HeavyCapacity)
	require.Equal(t, 4096, cfg.Queue.HeavyThreshold)
	require.Equal(t, "layered", cfg.Store.Type)
	require.Equal(t, 5, cfg.Store.Circuit.Failures)
	require.Equal(t, 5, cfg.Store.Circuit.CooldownSeconds)
	require.Equal(t, 20, cfg.Autoscale.MaxReplicas)
	require.Equal(t, 70, cfg.Autoscale.CPUUp)
	require.Equal(t, 10, cfg.Autoscale.PollSeconds)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/config/ -run TestLoadQueueAndAutoscale -v`
Expected: FAIL — `cfg.Queue undefined`

- [ ] **Step 3: Write minimal implementation**

Add to `internal/config/config.go`:

```go
// QueueConfig controls the worker pool.
type QueueConfig struct {
	Workers        int `yaml:"workers"`
	FastCapacity   int `yaml:"fast_capacity"`
	HeavyCapacity  int `yaml:"heavy_capacity"`
	HeavyThreshold int `yaml:"heavy_threshold"` // payload bytes longer => heavy queue
}

// CircuitConfig controls the Redis circuit breaker.
type CircuitConfig struct {
	Failures        int `yaml:"failures"`
	CooldownSeconds int `yaml:"cooldown_seconds"`
}

// AutoscaleConfig controls the Swarm autoscaler.
type AutoscaleConfig struct {
	MinReplicas    int `yaml:"min_replicas"`
	MaxReplicas    int `yaml:"max_replicas"`
	CPUUp          int `yaml:"cpu_up"`
	CPUDown        int `yaml:"cpu_down"`
	QueueUp        int `yaml:"queue_up"`
	LatencyP99MS   int `yaml:"latency_p99_ms"`
	CooldownSeconds int `yaml:"cooldown_seconds"`
	PollSeconds    int `yaml:"poll_seconds"`
}
```

Add fields to `StoreConfig`:

```go
type StoreConfig struct {
	Type     string        `yaml:"type"` // "memory" | "redis" | "layered"
	TTLHours int           `yaml:"ttl_hours"`
	Capacity int           `yaml:"capacity"`
	RedisURL string        `yaml:"redis_url"`
	Circuit  CircuitConfig `yaml:"circuit"`
}
```

Add fields to `Config`:

```go
type Config struct {
	// ... existing fields ...
	Queue     QueueConfig     `yaml:"queue"`
	Autoscale AutoscaleConfig `yaml:"autoscale"`
}
```

Add defaults in `Default()`:

```go
return &Config{
	// ... existing ...
	Queue: QueueConfig{Workers: 16, FastCapacity: 1024, HeavyCapacity: 256, HeavyThreshold: 4096},
	Autoscale: AutoscaleConfig{MinReplicas: 2, MaxReplicas: 20, CPUUp: 70, CPUDown: 30, QueueUp: 100, LatencyP99MS: 100, CooldownSeconds: 30, PollSeconds: 10},
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/config/ -run TestLoadQueueAndAutoscale -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/config/config.go internal/config/config_test.go
git commit -m "feat: queue, circuit, autoscale config"
```

---

