### Task 11: Update config.yaml and README

**Files:**
- Modify: `configs/config.yaml`
- Modify: `README.md`

**Interfaces:**
- Consumes: новые секции конфига (Task 4).
- Produces: документированная конфигурация и инструкция по Swarm-деплою.

- [ ] **Step 1: Update config.yaml**

Add to `configs/config.yaml`:

```yaml
queue:
  workers: 16
  fast_capacity: 1024
  heavy_capacity: 256
  heavy_threshold: 4096

store:
  type: layered
  ttl_hours: 24
  capacity: 262144
  redis_url: "redis://localhost:6379/0"
  circuit:
    failures: 5
    cooldown_seconds: 5

autoscale:
  min_replicas: 2
  max_replicas: 20
  cpu_up: 70
  cpu_down: 30
  queue_up: 100
  latency_p99_ms: 100
  cooldown_seconds: 30
  poll_seconds: 10
```

- [ ] **Step 2: Update README**

Add a section "Горизонтальное масштабирование (Docker Swarm)" describing:
- `docker stack deploy -c deploy/stack.yml pii`
- Автоскейлинг через autoscaler-контейнер
- Деградация при недоступности Redis

- [ ] **Step 3: Commit**

```bash
git add configs/config.yaml README.md
git commit -m "docs: swarm scaling config and README"
```

---

