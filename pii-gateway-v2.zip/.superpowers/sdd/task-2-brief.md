### Task 2: Layered store (Redis + local cache + breaker)

**Files:**
- Create: `internal/store/layered.go`
- Test: `internal/store/layered_test.go`

**Interfaces:**
- Consumes: `store.Store` (from `internal/store/store.go`), `store.RedisStore` (from `internal/store/redis.go`), `store.MemoryStore` (from `internal/store/memory.go`), `store.Breaker` (Task 1).
- Produces: `type LayeredStore struct`; `func NewLayered(redis *RedisStore, local *MemoryStore, breaker *Breaker) *LayeredStore`; implements `store.Store` (`Save(ctx, id, Entry) error`, `Get(ctx, id) (Entry, bool, error)`); `func (s *LayeredStore) RedisUp() bool`.

- [ ] **Step 1: Write the failing test**

```go
package store

import (
	"context"
	"testing"
	"time"

	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"
	"github.com/stretchr/testify/require"
)

func newLayered(t *testing.T) (*LayeredStore, *miniredis.Miniredis) {
	t.Helper()
	mr := miniredis.RunT(t)
	client := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	redisStore := NewRedis(client, time.Hour)
	local := NewMemory(time.Hour, 1000)
	breaker := NewBreaker(3, time.Minute)
	return NewLayered(redisStore, local, breaker), mr
}

func TestLayeredSaveGet(t *testing.T) {
	s, _ := newLayered(t)
	ctx := context.Background()
	require.NoError(t, s.Save(ctx, "id-1", Entry{Original: "orig"}))
	got, ok, err := s.Get(ctx, "id-1")
	require.NoError(t, err)
	require.True(t, ok)
	require.Equal(t, "orig", got.Original)
}

func TestLayeredRedisDownMaskStillWorks(t *testing.T) {
	s, mr := newLayered(t)
	ctx := context.Background()
	// Save while Redis is up.
	require.NoError(t, s.Save(ctx, "id-2", Entry{Original: "orig2"}))
	// Kill Redis.
	mr.Close()
	// Mask path: Save must not error (falls back to local cache).
	require.NoError(t, s.Save(ctx, "id-3", Entry{Original: "orig3"}))
	// Unmask path: local cache hit still works.
	got, ok, err := s.Get(ctx, "id-2")
	require.NoError(t, err)
	require.True(t, ok)
	require.Equal(t, "orig2", got.Original)
	require.False(t, s.RedisUp())
}

func TestLayeredRedisDownNoLocalMiss(t *testing.T) {
	s, mr := newLayered(t)
	ctx := context.Background()
	// Save to Redis only (bypass local by using a fresh layered store sharing
	// the same Redis but empty local).
	redisStore := NewRedis(redis.NewClient(&redis.Options{Addr: mr.Addr()}), time.Hour)
	require.NoError(t, redisStore.Save(ctx, "id-4", Entry{Original: "remote"}))
	mr.Close()
	// Local cache empty + Redis down -> miss, no error.
	_, ok, err := s.Get(ctx, "id-4")
	require.NoError(t, err)
	require.False(t, ok)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/store/ -run TestLayered -v`
Expected: FAIL — `undefined: NewLayered`

- [ ] **Step 3: Write minimal implementation**

```go
package store

import (
	"context"
	"log/slog"
)

// LayeredStore persists entries to Redis (source of truth) and a local
// in-memory cache (fast path + fallback). A circuit breaker guards Redis: when
// it is open, Save writes only to the local cache and Get serves only local
// hits. Masking never fails; unmask degrades to local-only.
type LayeredStore struct {
	redis   *RedisStore
	local   *MemoryStore
	breaker *Breaker
}

func NewLayered(redis *RedisStore, local *MemoryStore, breaker *Breaker) *LayeredStore {
	return &LayeredStore{redis: redis, local: local, breaker: breaker}
}

// RedisUp reports whether the breaker is closed (Redis reachable).
func (s *LayeredStore) RedisUp() bool { return s.breaker.State() }

func (s *LayeredStore) Save(ctx context.Context, id string, e Entry) error {
	// Always write to local cache first (fast path + fallback).
	if err := s.local.Save(ctx, id, e); err != nil {
		return err
	}
	if !s.breaker.Allow() {
		return nil // Redis open; local write is enough
	}
	if err := s.redis.Save(ctx, id, e); err != nil {
		s.breaker.Failure()
		slog.Warn("layered: redis save failed", "error", err)
		return nil // masking must not fail
	}
	s.breaker.Success()
	return nil
}

func (s *LayeredStore) Get(ctx context.Context, id string) (Entry, bool, error) {
	if e, ok, err := s.local.Get(ctx, id); err == nil && ok {
		return e, true, nil
	}
	if !s.breaker.Allow() {
		return Entry{}, false, nil // Redis open; no local hit
	}
	e, ok, err := s.redis.Get(ctx, id)
	if err != nil {
		s.breaker.Failure()
		slog.Warn("layered: redis get failed", "error", err)
		return Entry{}, false, nil
	}
	s.breaker.Success()
	if ok {
		_ = s.local.Save(ctx, id, e) // populate local cache
	}
	return e, ok, nil
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/store/ -run TestLayered -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/store/layered.go internal/store/layered_test.go
git commit -m "feat: layered store with local cache and circuit breaker"
```

---

