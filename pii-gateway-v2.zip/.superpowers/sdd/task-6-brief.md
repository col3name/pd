### Task 6: Wire pool + layered store into server

**Files:**
- Modify: `cmd/server/main.go`
- Modify: `internal/api/handlers/process.go`
- Test: `internal/api/handlers/process_test.go`

**Interfaces:**
- Consumes: `queue.Pool` (Task 3), `store.LayeredStore` (Task 2), `config.QueueConfig`/`config.CircuitConfig` (Task 4), `observability.QueueDepth`/`WorkersBusy`/`RedisUp` (Task 5).
- Produces: `Handler` gains a `Pool *queue.Pool` field; `Handler.Process` routes through the pool.

- [ ] **Step 1: Write the failing test**

Add to `internal/api/handlers/process_test.go`:

```go
func TestProcessThroughPool(t *testing.T) {
	h := newTestHandler(t)
	// Attach a pool to the handler.
	h.Pool = queue.New(4, 64, 16, func(payload string) queue.Result {
		res := h.Mgr.Pipeline("").Process(payload)
		return queue.Result{Masked: res.Masked, Types: res.Types, Tokens: res.Tokens}
	})
	defer h.Pool.Close()
	rec := doProcess(t, h, "паспорт 4509 123456", "pool-1")
	require.Equal(t, http.StatusOK, rec.Code)
	var resp ProcessResponse
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &resp))
	require.Contains(t, resp.Result, "[ПАСПОРТ]")
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/api/handlers/ -run TestProcessThroughPool -v`
Expected: FAIL — `undefined: queue`

- [ ] **Step 3: Write minimal implementation**

In `internal/api/handlers/process.go`, add the `Pool` field to `Handler`:

```go
type Handler struct {
	Mgr  *control.Manager
	Repo *db.Repo
	Pool *queue.Pool
}
```

Add import: `"github.com/kind-earthquake/pii-module/internal/queue"`.

In `Process`, replace the direct pipeline call with a pool submission when a pool is present. Add a helper:

```go
// runPipeline executes the pipeline directly or through the worker pool.
func (h *Handler) runPipeline(ctx context.Context, p *pipeline.Pipeline, payload string) (pipeline.Result, error) {
	if h.Pool == nil {
		return p.Process(payload), nil
	}
	heavy := len(payload) > h.Mgr.Config().Queue.HeavyThreshold
	res, err := h.Pool.Submit(ctx, payload, heavy)
	if err != nil {
		return pipeline.Result{}, err
	}
	return pipeline.Result{Masked: res.Masked, Types: res.Types, Tokens: res.Tokens}, nil
}
```

In `Process`, replace:

```go
res := p.Process(req.Payload)
```

with:

```go
res, err := h.runPipeline(r.Context(), p, req.Payload)
if err != nil {
	http.Error(w, "service busy", http.StatusServiceUnavailable)
	w.Header().Set("Retry-After", "1")
	return
}
```

In `cmd/server/main.go`, build the pool and layered store. Replace the store construction block:

```go
var st store.Store
var redisClient *redis.Client
if cfg.Store.Type == "redis" || cfg.Store.Type == "layered" {
	redisClient = redis.NewClient(redisOptions(cfg.Store.RedisURL))
	redisStore := store.NewRedis(redisClient, ttl)
	if cfg.Store.Type == "layered" {
		local := store.NewMemory(ttl, cfg.Store.Capacity)
		breaker := store.NewBreaker(cfg.Store.Circuit.Failures, time.Duration(cfg.Store.Circuit.CooldownSeconds)*time.Second)
		st = store.NewLayered(redisStore, local, breaker)
	} else {
		st = redisStore
	}
} else {
	st = store.NewMemory(ttl, cfg.Store.Capacity)
}
```

Build the pool after `h` is created:

```go
h := &handlers.Handler{Mgr: mgr, Repo: repo}
pool := queue.New(cfg.Queue.Workers, cfg.Queue.FastCapacity, cfg.Queue.HeavyCapacity, func(payload string) queue.Result {
	res := mgr.Pipeline("").Process(payload)
	return queue.Result{Masked: res.Masked, Types: res.Types, Tokens: res.Tokens}
})
h.Pool = pool
defer pool.Close()
```

Add imports `"github.com/kind-earthquake/pii-module/internal/queue"` to main.go.

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/api/handlers/ -run TestProcessThroughPool -v`
Expected: PASS

- [ ] **Step 5: Run full test suite**

Run: `go test ./...`
Expected: PASS

- [ ] **Step 6: Commit**

```bash
git add cmd/server/main.go internal/api/handlers/process.go internal/api/handlers/process_test.go
git commit -m "feat: route process through worker pool and layered store"
```

---

