### Task 1: Circuit breaker

**Files:**
- Create: `internal/store/circuit.go`
- Test: `internal/store/circuit_test.go`

**Interfaces:**
- Consumes: ничего.
- Produces: `type Breaker struct`; `func NewBreaker(failures int, cooldown time.Duration) *Breaker`; `func (b *Breaker) Allow() bool`; `func (b *Breaker) Success()`; `func (b *Breaker) Failure()`; `func (b *Breaker) State() bool` (true = closed/up).

- [ ] **Step 1: Write the failing test**

```go
package store

import (
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

func TestBreakerOpensAfterFailures(t *testing.T) {
	b := NewBreaker(3, time.Minute)
	require.True(t, b.Allow())
	b.Failure()
	b.Failure()
	require.True(t, b.Allow())
	b.Failure()
	require.False(t, b.Allow(), "breaker must open after 3 failures")
	require.False(t, b.State())
}

func TestBreakerRecoversAfterCooldown(t *testing.T) {
	b := NewBreaker(2, 50*time.Millisecond)
	b.Failure()
	b.Failure()
	require.False(t, b.Allow())
	time.Sleep(60 * time.Millisecond)
	require.True(t, b.Allow(), "breaker must close after cooldown")
	b.Success()
	require.True(t, b.State())
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/store/ -run TestBreaker -v`
Expected: FAIL — `undefined: NewBreaker`

- [ ] **Step 3: Write minimal implementation**

```go
package store

import (
	"sync"
	"time"
)

// Breaker is a simple circuit breaker. It opens after `failures` consecutive
// failures and stays open for `cooldown`, then allows a probe request.
type Breaker struct {
	mu        sync.Mutex
	failures  int
	threshold int
	cooldown  time.Duration
	openUntil time.Time
}

func NewBreaker(failures int, cooldown time.Duration) *Breaker {
	if failures <= 0 {
		failures = 1
	}
	return &Breaker{threshold: failures, cooldown: cooldown}
}

// Allow reports whether a call to the guarded resource is permitted now.
func (b *Breaker) Allow() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	if b.failures >= b.threshold && time.Now().Before(b.openUntil) {
		return false
	}
	return true
}

// Success resets the failure count.
func (b *Breaker) Success() {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.failures = 0
}

// Failure increments the failure count and opens the breaker when the
// threshold is reached.
func (b *Breaker) Failure() {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.failures++
	if b.failures >= b.threshold {
		b.openUntil = time.Now().Add(b.cooldown)
	}
}

// State reports whether the breaker is closed (up).
func (b *Breaker) State() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.failures < b.threshold || time.Now().After(b.openUntil)
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/store/ -run TestBreaker -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/store/circuit.go internal/store/circuit_test.go
git commit -m "feat: circuit breaker for store"
```

---

