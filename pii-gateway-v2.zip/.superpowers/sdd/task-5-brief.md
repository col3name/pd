### Task 5: New metrics (queue depth, workers busy, redis up)

**Files:**
- Modify: `internal/observability/metrics.go`
- Test: `internal/observability/metrics_test.go`

**Interfaces:**
- Consumes: ничего.
- Produces: `var QueueDepth prometheus.Gauge`; `var WorkersBusy prometheus.Gauge`; `var RedisUp prometheus.Gauge`.

- [ ] **Step 1: Write the failing test**

```go
package observability

import (
	"testing"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/testutil"
	"github.com/stretchr/testify/require"
)

func TestNewGaugesRegistered(t *testing.T) {
	QueueDepth.Set(5)
	WorkersBusy.Set(3)
	RedisUp.Set(1)
	require.NoError(t, prometheus.Register(prometheus.NewGaugeFunc(
		prometheus.GaugeOpts{Name: "pii_queue_depth"},
		func() float64 { return QueueDepth.Get() },
	)))
	_ = testutil.CollectAndCount(QueueDepth)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/observability/ -run TestNewGauges -v`
Expected: FAIL — `undefined: QueueDepth`

- [ ] **Step 3: Write minimal implementation**

Add to `internal/observability/metrics.go`:

```go
// QueueDepth is the current total depth of the worker-pool queues.
var QueueDepth = promauto.NewGauge(prometheus.GaugeOpts{
	Name: "pii_queue_depth",
	Help: "Current total depth of the worker-pool queues.",
})

// WorkersBusy is the number of workers currently processing a job.
var WorkersBusy = promauto.NewGauge(prometheus.GaugeOpts{
	Name: "pii_workers_busy",
	Help: "Number of workers currently processing a job.",
})

// RedisUp is 1 when the Redis circuit breaker is closed, 0 when open.
var RedisUp = promauto.NewGauge(prometheus.GaugeOpts{
	Name: "pii_redis_up",
	Help: "1 when Redis is reachable, 0 when the circuit breaker is open.",
})
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/observability/ -run TestNewGauges -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/observability/metrics.go internal/observability/metrics_test.go
git commit -m "feat: queue depth, workers busy, redis up metrics"
```

---

