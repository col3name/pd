# Task 8 Report: Autoscaler container

## What I implemented

Created a standalone Go module in `deploy/autoscaler/` that autoscales a Docker Swarm service based on Prometheus metrics:

- **`main.go`** — the autoscaler logic:
  - Reads `AUTOSCALE_*`-style env vars (`PROM_URL`, `SERVICE`, `MIN_REPLICAS`, `MAX_REPLICAS`, `CPU_UP`, `CPU_DOWN`, `QUEUE_UP`, `LATENCY_P99_MS`, `COOLDOWN_SECONDS`, `POLL_SECONDS`) with sensible defaults.
  - Polls Prometheus HTTP API for `pii_queue_depth` and p99 latency (`histogram_quantile` over `pii_latency_seconds_bucket`).
  - Reads current replica count via `docker service inspect`.
  - Scales up/down via `docker service scale` with cooldown gating and min/max bounds.
- **`Dockerfile`** — multi-stage build (golang:1.25-alpine → alpine:3.20 with docker-cli).
- **`go.mod`** — standalone module `autoscaler`, `go 1.25.0`.
- **`.gitignore`** — ignores the compiled `/autoscaler` binary (added to keep the build artifact out of git).

## What I tested

- `go build ./...` in `deploy/autoscaler/` → **BUILD OK** (no errors, no go.sum needed since only stdlib is used).

## Files changed

- `deploy/autoscaler/main.go` (new)
- `deploy/autoscaler/Dockerfile` (new)
- `deploy/autoscaler/go.mod` (new)
- `deploy/autoscaler/.gitignore` (new)

## Self-review findings

- The brief's code was transcribed exactly.
- **Issue found during commit:** the first commit accidentally included the compiled `autoscaler` binary (created by `go build`). I removed it from the index, deleted the file, added a `.gitignore`, and made a follow-up commit. The repo now contains only source files.
- No tests required (deploy component); verification is that it builds, which passed.

## Issues / concerns

- None blocking. Note: `cpuUp`/`cpuDown` are loaded from env but not actually used in the scaling decision (the loop only uses queue depth and latency). This matches the brief's code exactly, so I left it as-is.

---

## Fix Report: CPU as primary scaling signal

### What I changed

`deploy/autoscaler/main.go`:

1. **CPU query support.** Added a `cpuQuery` field to the `cfg` struct, loaded from the `CPU_QUERY` env var. Defaults to `avg(rate(container_cpu_usage_seconds_total{name=~".*pii.*"}[1m])) * 100` when unset.
2. **CPU in the scaling decision.** The main loop now queries CPU percentage and:
   - `scaleUp` when `cpu > cpuUp` OR `queueDepth > queueUp` OR `latency > latencyP99MS`.
   - `scaleDown` only when `cpu < cpuDown` AND `queueDepth < queueUp/10` AND `latency < latencyP99MS/10` (all three low).
   - CPU value is logged in the scale-up message.
3. **Minor fixes from review:**
   - `queryFloat` errors are no longer silently discarded — each query failure is logged to stderr and the poll cycle `continue`s without scaling (avoids spurious scale-downs when Prometheus is down).
   - `queryFloat` now checks `resp.StatusCode` and returns an error on non-200.
   - `currentReplicas` (and `scale`) now use a fresh 10s timeout context instead of `context.Background()`.

### Build command and output

```
$ cd deploy/autoscaler && go build ./...
(no output — build OK)
$ go vet ./...
(no output — vet OK)
```

### Files changed

- `deploy/autoscaler/main.go` (modified)
- `.superpowers/sdd/task-8-report.md` (this report)