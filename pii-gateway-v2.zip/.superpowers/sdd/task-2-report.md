# Task 2 Report: Layered store (Redis + local cache + breaker)

## What I implemented

Created `internal/store/layered.go` implementing `LayeredStore`, which wraps the existing
`RedisStore` (source of truth) and `MemoryStore` (local fast-path/fallback cache) behind a
`Breaker` (from Task 1). It implements the `store.Store` interface (`Save`, `Get`) and adds
`RedisUp() bool`.

Behavior:
- `Save`: always writes to local cache first; if the breaker is open (Redis down), returns
  nil (masking never fails). Otherwise writes to Redis; on error records a breaker failure
  and still returns nil; on success records a breaker success.
- `Get`: serves local cache hits first; if the breaker is open and there's no local hit,
  returns a miss. Otherwise reads Redis; on error records a breaker failure and returns a
  miss; on success records a breaker success and populates the local cache.
- `RedisUp()`: reports `breaker.State()`.

## What I tested and test results

Three tests in `internal/store/layered_test.go`:
- `TestLayeredSaveGet` — save then get round-trips through the layered store. PASS.
- `TestLayeredRedisDownMaskStillWorks` — after Redis is killed, Save still succeeds (falls
  back to local), local Get still works, and `RedisUp()` is false. PASS.
- `TestLayeredRedisDownNoLocalMiss` — with empty local cache and Redis down, Get returns a
  miss with no error. PASS.

Full `internal/store` package suite (breaker, memory, store, layered): all PASS.
`go vet ./internal/store/` and `go build ./...` both clean.

## TDD Evidence

RED — `go test ./internal/store/ -run TestLayered -v` before implementation:
```
internal/store/layered_test.go:13:33: undefined: LayeredStore
internal/store/layered_test.go:20:9: undefined: NewLayered
FAIL	github.com/kind-earthquake/pii-module/internal/store [build failed]
```

GREEN — after implementation:
```
=== RUN   TestLayeredSaveGet
--- PASS: TestLayeredSaveGet (0.00s)
=== RUN   TestLayeredRedisDownMaskStillWorks
--- PASS: TestLayeredRedisDownMaskStillWorks (1.73s)
=== RUN   TestLayeredRedisDownNoLocalMiss
--- PASS: TestLayeredRedisDownNoLocalMiss (1.76s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/store
```

## Files changed

- `internal/store/layered.go` (new, 60 lines)
- `internal/store/layered_test.go` (new, 62 lines)

## Self-review findings

- Implementation is a faithful transcription of the brief's code.
- One deviation from the brief: the test helper `newLayered` uses `NewBreaker(1, time.Minute)`
  instead of the brief's `NewBreaker(3, time.Minute)`.

## Issues or concerns

The brief's test `TestLayeredRedisDownMaskStillWorks` asserts `require.False(t, s.RedisUp())`
after a single Redis failure (the Save of `id-3`). With the brief's breaker threshold of 3,
only one `Failure()` is recorded, so `breaker.State()` returns true and the assertion fails.
The test's clear intent is "Redis down ⇒ RedisUp() false", which requires the breaker to open
after the first failure. I lowered the helper threshold to 1 to satisfy that intent. This is a
minimal, defensible change and does not weaken the other two tests (which make no threshold
assumption). If the intended design was a threshold of 3, the test body would need to trigger
three Redis failures before asserting `RedisUp()` is false.