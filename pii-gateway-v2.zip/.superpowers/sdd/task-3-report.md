# Task 3 Report: Worker pool with fast/heavy queues

## What I implemented

Created a new package `internal/queue` with a worker pool that has two queues:

- **fast** — for short payloads (low latency)
- **heavy** — for long payloads

The pool uses a future/promise pattern: each `Job` carries a buffered `done chan Result`, and `Submit` enqueues the job then blocks on that channel until a worker produces a result or the context expires.

Public API (per brief):
- `type Job struct { Payload string; Heavy bool; done chan Result }`
- `type Result struct { Masked string; Types []string; Tokens map[string]string; Err error }`
- `type Handler func(payload string) Result`
- `type Pool struct`; `func New(workers, fastCap, heavyCap int, h Handler) *Pool`
- `func (p *Pool) Submit(ctx context.Context, payload string, heavy bool) (Result, error)`
- `func (p *Pool) QueueDepth() int`
- `func (p *Pool) WorkersBusy() int`
- `func (p *Pool) Close()`
- `var ErrQueueFull = errors.New("queue full")`

Implementation details:
- `New` guards `workers <= 0` → defaults to 1.
- Each worker loops on a `select` over `done` (shutdown), `fast`, and `heavy`.
- `run` increments/decrements an `atomic.Int32` busy counter around the handler call.
- `Submit` does a non-blocking ctx check, then a select-enqueue into the appropriate queue (respecting ctx), then waits on `j.done` (respecting ctx). Returns `ErrQueueFull` on any ctx expiry.
- `done` channel is buffered (cap 1) so a worker never blocks sending a result even if the caller already timed out — no goroutine leak.
- `Close` closes `done` and waits on the WaitGroup.

## What I tested and test results

Four tests from the brief, all passing:

```
=== RUN   TestPoolProcessesJob
--- PASS: TestPoolProcessesJob (0.00s)
=== RUN   TestPoolBackpressure
--- PASS: TestPoolBackpressure (0.20s)
=== RUN   TestPoolMetrics
--- PASS: TestPoolMetrics (0.02s)
=== RUN   TestPoolHandlerError
--- PASS: TestPoolHandlerError (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/queue	0.710s
```

Also verified:
- `go test ./internal/queue/ -race -count=1` → PASS (no data races)
- `go build ./...` → OK
- `go vet ./internal/queue/` → OK

## TDD Evidence

**RED** — `go test ./internal/queue/ -v` (before implementation):
```
# github.com/kind-earthquake/pii-module/internal/queue [github.com/kind-earthquake/pii-module/internal/queue.test]
internal/queue/pool_test.go:14:7: undefined: New
internal/queue/pool_test.go:14:42: undefined: Result
internal/queue/pool_test.go:15:10: undefined: Result
internal/queue/pool_test.go:26:7: undefined: New
internal/queue/pool_test.go:26:41: undefined: Result
internal/queue/pool_test.go:28:10: undefined: Result
internal/queue/pool_test.go:48:7: undefined: New
internal/queue/pool_test.go:48:42: undefined: Result
internal/queue/pool_test.go:52:10: undefined: Result
internal/queue/pool_test.go:62:7: undefined: New
internal/queue/pool_test.go:62:7: too many errors
FAIL	github.com/kind-earthquake/pii-module/internal/queue [build failed]
FAIL
```

**GREEN** — `go test ./internal/queue/ -v` (after implementation):
```
=== RUN   TestPoolProcessesJob
--- PASS: TestPoolProcessesJob (0.00s)
=== RUN   TestPoolBackpressure
--- PASS: TestPoolBackpressure (0.20s)
=== RUN   TestPoolMetrics
--- PASS: TestPoolMetrics (0.02s)
=== RUN   TestPoolHandlerError
--- PASS: TestPoolHandlerError (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/queue	0.710s
```

## Files changed

- `internal/queue/pool.go` (new) — worker pool implementation
- `internal/queue/pool_test.go` (new) — tests

Commit: `b2d95f2 feat: worker pool with fast/heavy queues`

## Self-review findings

1. **Test bug fixed (deviation from brief)**: The brief's `TestPoolBackpressure` used `context.Background()` (no deadline) for the "b" and "c" submits. Because the single worker is blocked forever on `<-block`, those submits would block indefinitely waiting for a result that never arrives — the test hangs. I changed those two submits to use 50ms timeout contexts. This preserves the test's intent (fill the fast queue, then verify a subsequent submit errors on backpressure) without hanging. The "b"/"c" jobs still enqueue into the queue (worker never drains them) and time out waiting for results, so the queue ends up full and "d" correctly errors.

2. **No goroutine leak**: `done` channel is buffered (cap 1), so a worker's `j.done <- res` never blocks even if the caller already timed out and abandoned the wait.

3. **Close safety**: `Close()` closes `done` and waits on the WaitGroup. In the backpressure test, `close(block)` runs before `Close` (LIFO defer order), so the worker unblocks, drains queued jobs, then sees `done` and exits — no deadlock.

4. **Race safety**: `busy` is `atomic.Int32`; queues and `done` are channels; `QueueDepth` reads `len()` which is safe. `-race` passed.

5. **Edge case**: `New` guards `workers <= 0` → defaults to 1.

## Issues or concerns

- The only concern is the deviation from the brief's test (see finding #1). The brief's `TestPoolBackpressure` as written hangs indefinitely; I fixed it with timeout contexts. The implementation itself is unchanged from the brief.