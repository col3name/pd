# Task 10 Report: Degradation integration tests

## What I implemented

Added `TestProcessLayeredRedisDown` to `internal/api/handlers/process_test.go`. The test verifies the layered store's degradation behavior when Redis goes down:

1. **Mask while Redis is up** — `deg-1` payload "паспорт 4509 123456" is masked to contain `[ПАСПОРТ]`.
2. **Kill Redis** (`mr.Close()`).
3. **Unmask from local cache still works** — sending the masked result back with the same `deg-1` id returns the original "паспорт 4509 123456".
4. **Masking still works with Redis down** — a new payload `deg-2` is masked successfully (HTTP 200).

The test uses `store.NewBreaker(1, time.Minute)` so the breaker opens after one Redis failure, matching the layered store's fallback behavior.

## What I tested and test results

- Focused test: `go test ./internal/api/handlers/ -run TestProcessLayeredRedisDown -v` → **PASS** (1.71s)
- Full handlers package: `go test ./internal/api/handlers/` → **PASS**
- Full suite: `go test ./...` → **PASS** (all packages)

## TDD Evidence

The layered store (`store.NewLayered`) and its dependencies were already implemented in earlier tasks (Task 2/6), so the test passed on first run. This is a GREEN-only task — the RED phase was not applicable because the production code already existed.

**GREEN** — `go test ./internal/api/handlers/ -run TestProcessLayeredRedisDown -v`:
```
=== RUN   TestProcessLayeredRedisDown
... INFO process: masked payload_id=deg-1 ...
... INFO process: unmasked payload_id=deg-1 ...
... WARN layered: redis get failed error="dial tcp ...: connect: connection refused"
... INFO process: masked payload_id=deg-2 ...
--- PASS: TestProcessLayeredRedisDown (1.71s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/api/handlers	2.349s
```

## Files changed

- `internal/api/handlers/process_test.go` (+29 lines)

## Self-review findings

- The test faithfully transcribes the brief's code.
- It exercises all three degradation scenarios: mask-up, unmask-from-local, mask-down.
- The breaker (`NewBreaker(1, time.Minute)`) opens after the first Redis failure, correctly triggering local-only fallback.
- No production code changes were needed; the layered store already handles degradation correctly.

## Issues or concerns

None. The test passes and the full suite is green.