# Task 9 Report: Swarm stack + prometheus config

## What I implemented

1. **Created `deploy/stack.yml`** — a Docker Swarm stack with 5 services (`pii`, `redis`, `postgres`, `prometheus`, `autoscaler`) on an overlay network `pii-net`. Adjustments from the brief:
   - `pii` service uses `image: pii-module-v2:latest` (matches the root `Dockerfile` build tag `pii-module-v2`), not `pii-module:latest`.
   - `autoscaler` service uses `image: pii-autoscaler:latest` (matches the Task 8 autoscaler image).
   - Removed all `build:` sections — `docker stack deploy` requires pre-built images.
   - Kept all `deploy:` sections (replicas, update_config, resources, networks).
   - `pii` service: 2 replicas, CPU limit 1.0, memory 512M, env for PORT/DATABASE_DSN/STORE/REDIS_URL.
   - `autoscaler` service: mounts `/var/run/docker.sock`, env for PROM_URL/SERVICE/MIN/MAX_REPLICAS/CPU thresholds/QUEUE/LATENCY/COOLDOWN/POLL.

2. **Updated `prometheus.yml`** — replaced the old `pii-module` job (targeting `pii-module-v2:8080`) with a `pii` job targeting `pii:8080` (the Swarm service name) with `metrics_path: /metrics`. Kept `global.scrape_interval: 5s`.

## What I tested and test results

- `docker compose -f deploy/stack.yml config` → **exit 0**, valid config output. Only warning: `version` attribute is obsolete (harmless; brief's stack.yml includes it).
- Python `yaml.safe_load` on both `deploy/stack.yml` and `prometheus.yml` → **both parse OK**.

## Files changed

- `deploy/stack.yml` (created)
- `prometheus.yml` (modified)

## Self-review findings

- Image names reconciled with existing Dockerfiles (`pii-module-v2`, `pii-autoscaler`).
- No `build:` sections remain — stack is deployable via `docker stack deploy`.
- Prometheus target matches the Swarm service name `pii:8080`.
- All env vars from the brief preserved.
- `version: "3.8"` retained per brief despite being obsolete — harmless.

## Issues or concerns

- `docker stack deploy` requires the images to be built and pushed to a registry accessible by all Swarm nodes (or present locally on a single-node Swarm). The stack references local image tags (`pii-module-v2:latest`, `pii-autoscaler:latest`), so on a multi-node Swarm these must be pushed to a registry first.
- The `prometheus.yml` volume mount `./prometheus.yml` is relative to the stack file location; on a multi-node Swarm the file must exist on each node (or use a config). Acceptable for a single-node demo.
- `version` key is obsolete in current Compose; could be removed but kept to match the brief.