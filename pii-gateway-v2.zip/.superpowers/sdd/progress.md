# Progress Ledger: Horizontal Scaling on Docker Swarm

Plan: docs/superpowers/plans/2026-09-23-horizontal-scaling-swarm.md
Branch: main (user-consented)
Base commit before task 1: a077443

## Status

Task 1: complete (commit ce111e7, review clean; minors: State/Allow boundary, cooldown<=0 unguarded, failures unbounded, narrow coverage, Sleep flake — roll up)
Task 2: complete (commit 755405a, review clean; implementer fixed plan bug: test helper threshold 3→1 to match RedisUp assertion; minors: trailing newlines, loose local.Get error guard, swallowed populate-cache error — roll up)
Task 3: complete (commit b2d95f2, review clean; implementer fixed plan bug: TestPoolBackpressure context.Background hang → 50ms timeouts; minors: test comment imprecision, weak TestPoolMetrics, trailing newlines, unbuffered-queue edge — roll up)
Task 4: complete (commit 8cab270, review clean; minors: test asserts only 3/8 autoscale fields — roll up)
Task 5: complete (commit 5f60603, review clean; implementer fixed plan bug: brief test used Gauge.Get() (no such method) + Register of promauto metric (always fails) → testutil.ToFloat64/CollectAndCount; minors: trailing newlines — roll up)
Task 6: complete (commits 20e336f + fix dd44058, review clean after fix; Important fixed: pool worker ignored per-system pipeline → carried System through Job/Handler/Submit, main.go resolves mgr.Pipeline(system), TestProcessThroughPoolRespectsSystem added; minors: dead errSystemDisabled in direct path, res.Err dropped, test doesn't guard main.go closure — roll up)
Task 7: complete (commit 6bc7fc4, review clean; implementer fixed plan bug: brief test used old 1-arg queue.Handler + Gauge.Get() → 2-arg + testutil.ToFloat64; minors: weak >=0 assertion, RedisUp branch untested, trailing newlines — roll up)
Task 8: complete (commits 311e70d + f38309a + fix b9272de, review clean after fix; Important fixed: CPU was dead config → added CPU_QUERY, CPU as primary scaleUp signal, scaleDown requires all three low, query errors short-circuit; minors: queryFloat type-assert panic, io.ReadAll err ignored, no PROM_URL/SERVICE validation, scaleDown msg omits values, dctx reuse, CPU query depends on cAdvisor — roll up)
Task 9: complete (commit 96e5fcf, review clean; implementer reconciled image names pii-module-v2/pii-autoscaler, removed build: sections for Swarm; minors: obsolete version 3.8, trailing newlines, cAdvisor integration risk (autoscaler CPU query needs cAdvisor not in stack) — roll up)
Task 10: complete (commit cabd069, review clean; GREEN-only task since layered store already existed; minors: skipped RED, unmask path doesn't exercise breaker, step 4 only asserts 200 — roll up)
Task 11: complete (commit ac50ae9, review clean; implementer also updated config_test.go for layered store type; minors: README references pii_gateway (should be pii), README says autoscaler params in config.yaml (they're in stack.yml env) — roll up)
Task 12: complete (verification clean; go test ./... all pass, go vet clean, go build clean, bench 33k RPS 0 fail, autoscaler builds)

Tasks 1-12: ALL COMPLETE

## Minor findings (roll-up for final review)

(none yet)