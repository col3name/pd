# Task 4 Report: Config for queue, store circuit, autoscale

## What I implemented

Added three new config structs and wired them into the existing `internal/config/config.go`:

- `QueueConfig` — `Workers`, `FastCapacity`, `HeavyCapacity`, `HeavyThreshold` (worker pool tuning).
- `CircuitConfig` — `Failures`, `CooldownSeconds` (Redis circuit breaker).
- `AutoscaleConfig` — `MinReplicas`, `MaxReplicas`, `CPUUp`, `CPUDown`, `QueueUp`, `LatencyP99MS`, `CooldownSeconds`, `PollSeconds` (Swarm autoscaler).

Also:
- Added `Circuit CircuitConfig` field to `StoreConfig` (and updated the `type` comment to include `"layered"`).
- Added `Queue QueueConfig` and `Autoscale AutoscaleConfig` fields to `Config`.
- Added defaults in `Default()` for `Queue` and `Autoscale`.

All structs use `yaml` tags matching the brief. No comments added beyond the brief's own doc comments.

## What I tested and test results

Added `TestLoadQueueAndAutoscale` to `internal/config/config_test.go` (transcribed from the brief). It writes a YAML file with queue/store.circuit/autoscale sections, loads it, and asserts all parsed values.

- Focused test: `go test ./internal/config/ -run TestLoadQueueAndAutoscale -v` → PASS
- Full package: `go test ./internal/config/ -v` → all 5 tests PASS
- `go vet ./internal/config/` → clean
- `go build ./...` → clean

## TDD Evidence

**RED** — `go test ./internal/config/ -run TestLoadQueueAndAutoscale -v`:
```
internal/config/config_test.go:97:26: cfg.Queue undefined (type *Config has no field or method Queue)
internal/config/config_test.go:98:28: cfg.Queue undefined (type *Config has no field or method Queue)
...
FAIL	github.com/kind-earthquake/pii-module/internal/config [build failed]
```

**GREEN** — same command after implementation:
```
=== RUN   TestLoadQueueAndAutoscale
--- PASS: TestLoadQueueAndAutoscale (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/config	0.519s
```

## Files changed

- `internal/config/config.go` (modified)
- `internal/config/config_test.go` (modified)

## Self-review findings

- Implementation matches the brief's code exactly (structs, fields, defaults).
- `go vet` and `go build ./...` pass; no regressions in the existing config tests.
- Defaults are consistent with the brief (Workers 16, FastCapacity 1024, HeavyCapacity 256, HeavyThreshold 4096; autoscale Min 2 / Max 20 / CPUUp 70 / CPUDown 30 / QueueUp 100 / LatencyP99MS 100 / Cooldown 30 / Poll 10).
- No concerns.

## Issues or concerns

None.