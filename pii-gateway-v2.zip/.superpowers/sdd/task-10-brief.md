### Task 10: Degradation integration tests

**Files:**
- Modify: `internal/api/handlers/process_test.go`

**Interfaces:**
- Consumes: `store.LayeredStore` (Task 2), `queue.Pool` (Task 3).
- Produces: тесты деградации при недоступном Redis.

- [ ] **Step 1: Write the failing test**

Add to `internal/api/handlers/process_test.go`:

```go
func TestProcessLayeredRedisDown(t *testing.T) {
	mr := miniredis.RunT(t)
	client := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	redisStore := store.NewRedis(client, time.Hour)
	local := store.NewMemory(time.Hour, 1000)
	breaker := store.NewBreaker(1, time.Minute)
	layered := store.NewLayered(redisStore, local, breaker)
	m, err := control.New(control.WithConfig(config.Default()), control.WithStore(layered))
	require.NoError(t, err)
	h := &Handler{Mgr: m}
	// Mask while Redis is up.
	rec := doProcess(t, h, "паспорт 4509 123456", "deg-1")
	require.Equal(t, http.StatusOK, rec.Code)
	var resp ProcessResponse
	require.NoError(t, json.Unmarshal(rec.Body.Bytes(), &resp))
	require.Contains(t, resp.Result, "[ПАСПОРТ]")
	// Kill Redis.
	mr.Close()
	// Unmask from local cache still works.
	rec2 := doProcess(t, h, resp.Result, "deg-1")
	require.Equal(t, http.StatusOK, rec2.Code)
	var resp2 ProcessResponse
	require.NoError(t, json.Unmarshal(rec2.Body.Bytes(), &resp2))
	require.Equal(t, "паспорт 4509 123456", resp2.Result)
	// Masking still works with Redis down.
	rec3 := doProcess(t, h, "паспорт 4509 123456", "deg-2")
	require.Equal(t, http.StatusOK, rec3.Code)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/api/handlers/ -run TestProcessLayeredRedisDown -v`
Expected: FAIL — `undefined: store.NewLayered` (if not yet wired) or behavior mismatch

- [ ] **Step 3: Run test to verify it passes**

Run: `go test ./internal/api/handlers/ -run TestProcessLayeredRedisDown -v`
Expected: PASS (after Task 2/6 are done)

- [ ] **Step 4: Run full test suite**

Run: `go test ./...`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/api/handlers/process_test.go
git commit -m "test: layered store degradation when redis is down"
```

---

