# Task 6 Report: Wire pool + layered store into server

## What I implemented

Wired the worker pool (`internal/queue`) and layered store (`internal/store`) into the server.

### `internal/api/handlers/process.go`
- Added `Pool *queue.Pool` field to the `Handler` struct.
- Added `runPipeline(ctx, p, payload)` helper that:
  - Falls back to a direct `p.Process(payload)` call when `h.Pool == nil` (keeps existing tests working).
  - Otherwise routes through `h.Pool.Submit(ctx, payload, heavy)` where `heavy = len(payload) > h.Mgr.Config().Queue.HeavyThreshold`.
  - Maps `queue.Result` back to `pipeline.Result`.
- Replaced the direct `res := p.Process(req.Payload)` call in `Process` with `h.runPipeline(...)`, returning `503 Service Unavailable` + `Retry-After: 1` when the pool is full.
- Added `context` and `queue` imports.

### `cmd/server/main.go`
- Extended the store construction to support `cfg.Store.Type == "layered"`: builds a `store.NewLayered(redisStore, local, breaker)` with a `store.NewBreaker(cfg.Store.Circuit.Failures, cooldown)`.
- Built the worker pool after the handler is created and attached it via `h.Pool = pool`, with `defer pool.Close()`.
- Added `queue` import.

## What I tested and test results

- `TestProcessThroughPool` (new): attaches a pool to the handler, processes "паспорт 4509 123456", asserts 200 and `[ПАСПОРТ]` in the result. **PASS**.
- Full `internal/api/handlers` package: **PASS** (all existing tests still pass via the `h.Pool == nil` fallback).
- `go build ./...`: **PASS**.
- Full `go test ./...`: **PASS** (all packages).

## TDD Evidence

### RED
Command: `go test ./internal/api/handlers/ -run TestProcessThroughPool -v`
```
internal/api/handlers/process_test.go:45:4: h.Pool undefined (type *Handler has no field or method Pool)
internal/api/handlers/process_test.go:49:10: h.Pool undefined (type *Handler has no field or method Pool)
FAIL	github.com/kind-earthquake/pii-module/internal/api/handlers [build failed]
```

### GREEN
Command: `go test ./internal/api/handlers/ -run TestProcessThroughPool -v`
```
=== RUN   TestProcessThroughPool
2026/09/23 23:10:09 INFO process: masked payload_id=pool-1 system="" types=[ПАСПОРТ] latency_ms=0
--- PASS: TestProcessThroughPool (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/api/handlers	0.615s
```

## Files changed

- `cmd/server/main.go` (modified)
- `internal/api/handlers/process.go` (modified)
- `internal/api/handlers/process_test.go` (modified)

## Self-review findings

- `runPipeline` correctly falls back to direct pipeline execution when `h.Pool == nil`, so all pre-existing handler tests pass unchanged.
- The pool handler in both `main.go` and the test uses `mgr.Pipeline("").Process(payload)` and maps `queue.Result` fields — consistent with the `queue.Handler` signature.
- `heavy` threshold uses `len(payload)` (byte length), matching the brief exactly.
- Layered store construction matches the brief; `store.NewBreaker` and `store.NewMemory` signatures verified against source.
- 503 + `Retry-After: 1` returned on `ErrQueueFull`, matching the brief.

## Issues or concerns

- None blocking. Minor: the heavy-threshold uses byte length rather than rune count; this matches the brief and is acceptable for the threshold's purpose.

---

# Task 6 Fix: Carry per-system pipeline through the worker pool

## What I changed

Fixed the bug where the worker pool ignored the per-system pipeline and always processed with the default pipeline (`mgr.Pipeline("")`), silently bypassing per-system masking policy.

### `internal/queue/pool.go`
- Added `System string` field to the `Job` struct.
- Changed `Handler` type from `func(payload string) Result` to `func(system, payload string) Result`.
- Changed `run(h Handler, j Job)` to call `h(j.System, j.Payload)`.
- Changed `Submit` signature from `Submit(ctx, payload, heavy)` to `Submit(ctx, system, payload, heavy)`, setting `System: system` in the Job literal.

### `internal/api/handlers/process.go`
- Changed `runPipeline` signature from `runPipeline(ctx, p *pipeline.Pipeline, payload)` to `runPipeline(ctx, system, payload string) (pipeline.Result, error)`.
- Pool path: calls `h.Pool.Submit(ctx, system, payload, heavy)`.
- Direct path (`h.Pool == nil`): resolves `p := h.systemPipeline(system)` and calls `p.Process(payload)`; returns `errSystemDisabled` when the pipeline is not ok.
- Added `errSystemDisabled` sentinel error.
- Updated the caller at line 140 to `h.runPipeline(r.Context(), req.System, req.Payload)`.
- The pre-existing `systemPipeline` check in `Process` (403 for disabled systems) now discards the unused pipeline value (`_, ok :=`).

### `cmd/server/main.go`
- Changed the pool handler closure to resolve the per-system pipeline: `func(system, payload string) queue.Result { res := mgr.Pipeline(system).Process(payload); ... }`.

### `internal/api/handlers/process_test.go`
- Updated `TestProcessThroughPool` to the new `queue.Handler` signature `func(system, payload string) queue.Result` and the new `Submit` signature.
- Added `TestProcessThroughPoolRespectsSystem`: a system restricted to PHONE and EMAIL, processed through the pool, asserts only phone/email are masked while ФИО and паспорт are not.

### `internal/queue/pool_test.go`
- Updated all pool tests to the new `Handler` and `Submit` signatures; `TestPoolProcessesJob` now also asserts the system name is threaded through.

## Covering tests run

- `TestProcessThroughPool` — PASS
- `TestProcessThroughPoolRespectsSystem` (new) — PASS
- `TestPoolProcessesJob`, `TestPoolBackpressure`, `TestPoolMetrics`, `TestPoolHandlerError` — PASS

Commands and output:

```
$ go test ./internal/queue/ -run 'TestPool' -v
--- PASS: TestPoolProcessesJob (0.00s)
--- PASS: TestPoolBackpressure (0.20s)
--- PASS: TestPoolMetrics (0.02s)
--- PASS: TestPoolHandlerError (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/queue	0.607s

$ go test ./internal/api/handlers/ -run 'TestProcessThroughPool' -v
--- PASS: TestProcessThroughPool (0.00s)
--- PASS: TestProcessThroughPoolRespectsSystem (0.00s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/api/handlers	0.516s

$ go test ./internal/queue/ ./internal/api/handlers/ ./internal/store/
ok  	github.com/kind-earthquake/pii-module/internal/queue	0.447s
ok  	github.com/kind-earthquake/pii-module/internal/api/handlers	4.196s
ok  	github.com/kind-earthquake/pii-module/internal/store	(cached)

$ go build ./...
(no output — success)

$ go test ./...
ok  	github.com/kind-earthquake/pii-module	(cached)
... (all packages ok)
```

## Files changed

- `internal/queue/pool.go` (modified)
- `internal/queue/pool_test.go` (modified)
- `internal/api/handlers/process.go` (modified)
- `internal/api/handlers/process_test.go` (modified)
- `cmd/server/main.go` (modified)