### Task 3: Worker pool with fast/heavy queues

**Files:**
- Create: `internal/queue/pool.go`
- Test: `internal/queue/pool_test.go`

**Interfaces:**
- Consumes: ничего.
- Produces:
  - `type Job struct { Payload string; Heavy bool }`
  - `type Result struct { Masked string; Types []string; Tokens map[string]string; Err error }`
  - `type Handler func(payload string) Result`
  - `type Pool struct`; `func New(workers, fastCap, heavyCap int, h Handler) *Pool`
  - `func (p *Pool) Submit(ctx context.Context, payload string, heavy bool) (Result, error)`
  - `func (p *Pool) QueueDepth() int`
  - `func (p *Pool) WorkersBusy() int`
  - `func (p *Pool) Close()`

- [ ] **Step 1: Write the failing test**

```go
package queue

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

func TestPoolProcessesJob(t *testing.T) {
	p := New(2, 16, 8, func(payload string) Result {
		return Result{Masked: "masked:" + payload}
	})
	defer p.Close()
	res, err := p.Submit(context.Background(), "hello", false)
	require.NoError(t, err)
	require.Equal(t, "masked:hello", res.Masked)
}

func TestPoolBackpressure(t *testing.T) {
	// Handler blocks forever; fill the fast queue, then Submit must time out.
	block := make(chan struct{})
	p := New(1, 2, 2, func(payload string) Result {
		<-block
		return Result{}
	})
	defer p.Close()
	defer close(block)
	// Occupy the single worker.
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	_, _ = p.Submit(ctx, "a", false)
	cancel()
	// Fill the fast queue (capacity 2).
	_, _ = p.Submit(context.Background(), "b", false)
	_, _ = p.Submit(context.Background(), "c", false)
	// Next submit with a short timeout -> error (queue full).
	ctx2, cancel2 := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel2()
	_, err := p.Submit(ctx2, "d", false)
	require.Error(t, err)
}

func TestPoolMetrics(t *testing.T) {
	var busy atomic.Int32
	p := New(2, 16, 8, func(payload string) Result {
		busy.Add(1)
		time.Sleep(20 * time.Millisecond)
		busy.Add(-1)
		return Result{}
	})
	defer p.Close()
	_, _ = p.Submit(context.Background(), "x", false)
	require.GreaterOrEqual(t, p.WorkersBusy(), 0)
	require.GreaterOrEqual(t, p.QueueDepth(), 0)
	_ = busy.Load()
}

func TestPoolHandlerError(t *testing.T) {
	p := New(1, 4, 4, func(payload string) Result {
		return Result{Err: errors.New("boom")}
	})
	defer p.Close()
	res, err := p.Submit(context.Background(), "x", false)
	require.NoError(t, err)
	require.Error(t, res.Err)
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/queue/ -v`
Expected: FAIL — `undefined: New`

- [ ] **Step 3: Write minimal implementation**

```go
package queue

import (
	"context"
	"errors"
	"sync"
	"sync/atomic"
)

// ErrQueueFull is returned when both queues are full and the context expires.
var ErrQueueFull = errors.New("queue full")

// Job is a unit of work submitted to the pool.
type Job struct {
	Payload string
	Heavy   bool
	done    chan Result
}

// Result is the outcome of processing a Job.
type Result struct {
	Masked string
	Types  []string
	Tokens map[string]string
	Err    error
}

// Handler processes a payload into a Result.
type Handler func(payload string) Result

// Pool runs a fixed number of workers consuming from two queues: fast (short
// payloads, low latency) and heavy (long payloads). Submit blocks until a
// worker produces a result or the context expires.
type Pool struct {
	fast  chan Job
	heavy chan Job
	done  chan struct{}
	wg    sync.WaitGroup
	busy  atomic.Int32
}

// New returns a Pool with `workers` goroutines and the given queue capacities.
func New(workers, fastCap, heavyCap int, h Handler) *Pool {
	if workers <= 0 {
		workers = 1
	}
	p := &Pool{
		fast:  make(chan Job, fastCap),
		heavy: make(chan Job, heavyCap),
		done:  make(chan struct{}),
	}
	for i := 0; i < workers; i++ {
		p.wg.Add(1)
		go p.worker(h)
	}
	return p
}

func (p *Pool) worker(h Handler) {
	defer p.wg.Done()
	for {
		select {
		case <-p.done:
			return
		case j := <-p.fast:
			p.run(h, j)
		case j := <-p.heavy:
			p.run(h, j)
		}
	}
}

func (p *Pool) run(h Handler, j Job) {
	p.busy.Add(1)
	res := h(j.Payload)
	p.busy.Add(-1)
	j.done <- res
}

// Submit enqueues a job and waits for its result. It returns ErrQueueFull if
// the context expires before a worker picks up the job.
func (p *Pool) Submit(ctx context.Context, payload string, heavy bool) (Result, error) {
	j := Job{Payload: payload, Heavy: heavy, done: make(chan Result, 1)}
	select {
	case <-ctx.Done():
		return Result{}, ErrQueueFull
	default:
	}
	if heavy {
		select {
		case p.heavy <- j:
		case <-ctx.Done():
			return Result{}, ErrQueueFull
		}
	} else {
		select {
		case p.fast <- j:
		case <-ctx.Done():
			return Result{}, ErrQueueFull
		}
	}
	select {
	case res := <-j.done:
		return res, nil
	case <-ctx.Done():
		return Result{}, ErrQueueFull
	}
}

// QueueDepth returns the total number of queued jobs.
func (p *Pool) QueueDepth() int {
	return len(p.fast) + len(p.heavy)
}

// WorkersBusy returns the number of workers currently processing.
func (p *Pool) WorkersBusy() int {
	return int(p.busy.Load())
}

// Close stops the workers and waits for them to finish.
func (p *Pool) Close() {
	close(p.done)
	p.wg.Wait()
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/queue/ -v`
Expected: PASS

- [ ] **Step 5: Commit**

```bash
git add internal/queue/pool.go internal/queue/pool_test.go
git commit -m "feat: worker pool with fast/heavy queues"
```

---

