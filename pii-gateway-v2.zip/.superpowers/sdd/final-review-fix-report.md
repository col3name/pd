# Final Whole-Branch Review — Fix Report

## What changed (per finding)

### Critical 1: Autoscaler non-functional (CPU query depends on cAdvisor not in stack)
- `deploy/autoscaler/main.go`: CPU query failure is now **non-fatal**. On error it logs `(using cpu=0)` and sets `cpu = 0` instead of `continue`-ing, so queue/latency scaling still runs.
- `deploy/stack.yml`: added a `cadvisor` service (`gcr.io/cadvisor/cadvisor:latest`) with the required ro mounts (`/:/rootfs:ro`, `/var/run:/var/run:ro`, `/sys:/sys:ro`, `/var/lib/docker/:/var/lib/docker:ro`, `/dev/disk/:/dev/disk:ro`), `privileged: true`, on `pii-net`.
- `prometheus.yml`: added a `cadvisor` scrape job targeting `cadvisor:8080`.

### Important 2: Unmask with Redis down + no local hit re-masks instead of 503
- `internal/store/layered.go`: added sentinel `var ErrRedisUnavailable = errors.New("redis unavailable")`. `LayeredStore.Get` now returns `(Entry{}, false, ErrRedisUnavailable)` when the breaker is open with no local hit, and when the Redis `Get` errors.
- `internal/api/handlers/process.go`: in the unmask lookup block, `errors.Is(err, store.ErrRedisUnavailable)` now returns `503 "unmask unavailable: storage degraded"` instead of falling through to re-mask.

### Important 3: `res.Err` from the pool silently dropped
- `internal/api/handlers/process.go` `runPipeline`: after `Submit` succeeds, `res.Err` is now checked and returned as an error so the handler returns 503.

### Important 4: README documents wrong service name and config location
- `README.md`: autoscaler section now references service `pii` (not `pii_gateway`) and documents that tuning is via `deploy/stack.yml` env vars (not `configs/config.yaml`).

### Minor fixes
- `internal/store/circuit.go`: `NewBreaker` guards `cooldown <= 0` (defaults to 1s).
- `internal/store/circuit.go`: `State()` and `Allow()` now use consistent boundary semantics (`!time.Now().After(openUntil)` in `Allow`, `time.Now().After(openUntil)` in `State`).
- `deploy/autoscaler/main.go`: guarded the `Value[1].(string)` type assertion with `v, ok := ...(string)`.
- `deploy/autoscaler/main.go`: checked the `io.ReadAll` error.
- `deploy/autoscaler/main.go`: added metric values to the scale-down log message.
- `internal/api/handlers/process.go`: removed the dead `errSystemDisabled` variable and its check in the direct path of `runPipeline` (Process already returns 403 before runPipeline is reached).

## Tests

Covering tests run:
- `TestLayeredRedisDownNoLocalMiss` (updated to expect `ErrRedisUnavailable`)
- `TestLayeredRedisDownNoLocalHitReturnsErrRedisUnavailable` (new)
- `TestProcessLayeredRedisDown` (updated: third request now expects 503)
- `TestProcessLayeredRedisDownUnmaskNoLocalHit503` (new)

Commands and output:
```
$ go test ./internal/store/ -run 'TestLayered|TestCircuit' -v
--- PASS: TestLayeredSaveGet
--- PASS: TestLayeredRedisDownMaskStillWorks
--- PASS: TestLayeredRedisDownNoLocalMiss
--- PASS: TestLayeredRedisDownNoLocalHitReturnsErrRedisUnavailable
PASS

$ go test ./internal/api/handlers/ ./internal/store/
ok  github.com/kind-earthquake/pii-module/internal/api/handlers
ok  github.com/kind-earthquake/pii-module/internal/store

$ go test ./...
ok  (all packages)

$ go vet ./...
(clean)

$ go build ./...
(clean)

$ cd deploy/autoscaler && go build ./...
(clean)
```

## Files changed
- `deploy/autoscaler/main.go`
- `deploy/stack.yml`
- `prometheus.yml`
- `internal/store/layered.go`
- `internal/store/circuit.go`
- `internal/store/layered_test.go`
- `internal/api/handlers/process.go`
- `internal/api/handlers/process_test.go`
- `README.md`

---

## Follow-up fix: masking must work with Redis down

### What changed
The previous fix returned 503 on any `store.ErrRedisUnavailable` from the lookup, which broke the degradation contract ("Маскирование работает всегда (не требует Redis)"). A brand-new mask request with Redis down and no local hit incorrectly returned 503.

- `internal/api/handlers/process.go`:
  - Added `looksLikeMasked(payload string) bool` helper. It returns true when the payload contains any token-mode prefix (`[PERSON_`, `[PHONE_`, `[EMAIL_`, `[CARD_`, `[PASSPORT_`, `[DATE_`, `[INN_`, `[FIO_`, `[ADDRESS_`, `[CVV_`, `[PIN_`, `[SNILS_`) or any redact-style placeholder (`[ПАСПОРТ]`, `[КАРТА]`, `[EMAIL]`, `[ТЕЛЕФОН]`, `[ДАТА]`, `[ИНН]`, `[ФИО]`, `[CVV]`, `[ПИН]`, `[ДАТА_РОЖДЕНИЯ]`, `[АДРЕС]`, `[СНИЛС]`).
  - In the `ErrRedisUnavailable` branch: if `looksLikeMasked(req.Payload)` → 503 (unmask attempt that can't be served without Redis); otherwise it's a new mask request → falls through to mask (masking works without Redis).
  - Added `strings` import.

### Tests
Covering tests run:
- `TestProcessLayeredRedisDown` (updated: third request with a fresh plaintext payload now expects 200 + masked result, not 503)
- `TestProcessLayeredRedisDownUnmaskNoLocalHit503` (updated: payload now carries mask tokens `[PERSON_001]`/`[PASSPORT_002]` so it's a genuine unmask attempt → 503)
- `TestProcessLayeredRedisDownNewMaskStillWorks` (new: fresh plaintext mask request with Redis down → 200 + masked)

Commands and output:
```
$ go test ./internal/api/handlers/ -run 'TestProcessLayeredRedisDown' -v
--- PASS: TestProcessLayeredRedisDown (1.78s)
--- PASS: TestProcessLayeredRedisDownUnmaskNoLocalHit503 (1.70s)
--- PASS: TestProcessLayeredRedisDownNewMaskStillWorks (1.71s)
PASS

$ go test ./...
ok  (all packages)

$ go vet ./...
(clean)

$ go build ./...
(clean)
```

### Files changed
- `internal/api/handlers/process.go`
- `internal/api/handlers/process_test.go`