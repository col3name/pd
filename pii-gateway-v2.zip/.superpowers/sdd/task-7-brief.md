### Task 7: Metrics reporting loop (queue depth, workers busy, redis up)

**Files:**
- Create: `internal/observability/reporter.go`
- Test: `internal/observability/reporter_test.go`

**Interfaces:**
- Consumes: `queue.Pool` (Task 3), `store.LayeredStore` (Task 2), `observability.QueueDepth`/`WorkersBusy`/`RedisUp` (Task 5).
- Produces: `func StartReporter(ctx context.Context, pool *queue.Pool, layered *store.LayeredStore, interval time.Duration)`.

- [ ] **Step 1: Write the failing test**

```go
package observability

import (
	"context"
	"testing"
	"time"

	"github.com/stretchr/testify/require"

	"github.com/kind-earthquake/pii-module/internal/queue"
	"github.com/kind-earthquake/pii-module/internal/store"
)

func TestReporterSetsGauges(t *testing.T) {
	p := queue.New(2, 8, 4, func(payload string) queue.Result { return queue.Result{} })
	defer p.Close()
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	StartReporter(ctx, p, nil, 10*time.Millisecond)
	time.Sleep(30 * time.Millisecond)
	require.GreaterOrEqual(t, QueueDepth.Get(), float64(0))
	require.GreaterOrEqual(t, WorkersBusy.Get(), float64(0))
}
```

- [ ] **Step 2: Run test to verify it fails**

Run: `go test ./internal/observability/ -run TestReporter -v`
Expected: FAIL — `undefined: StartReporter`

- [ ] **Step 3: Write minimal implementation**

```go
package observability

import (
	"context"
	"time"

	"github.com/kind-earthquake/pii-module/internal/queue"
	"github.com/kind-earthquake/pii-module/internal/store"
)

// StartReporter periodically publishes pool and store health to Prometheus
// gauges. It runs until ctx is cancelled.
func StartReporter(ctx context.Context, pool *queue.Pool, layered *store.LayeredStore, interval time.Duration) {
	if interval <= 0 {
		interval = time.Second
	}
	go func() {
		ticker := time.NewTicker(interval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				if pool != nil {
					QueueDepth.Set(float64(pool.QueueDepth()))
					WorkersBusy.Set(float64(pool.WorkersBusy()))
				}
				if layered != nil {
					if layered.RedisUp() {
						RedisUp.Set(1)
					} else {
						RedisUp.Set(0)
					}
				}
			}
		}
	}()
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `go test ./internal/observability/ -run TestReporter -v`
Expected: PASS

- [ ] **Step 5: Wire into main.go**

In `cmd/server/main.go`, after building the pool and store, start the reporter:

```go
var layeredStore *store.LayeredStore
if ls, ok := st.(*store.LayeredStore); ok {
	layeredStore = ls
}
reporterCtx, stopReporter := context.WithCancel(context.Background())
defer stopReporter()
observability.StartReporter(reporterCtx, pool, layeredStore, time.Duration(cfg.Autoscale.PollSeconds)*time.Second)
```

- [ ] **Step 6: Run full test suite**

Run: `go test ./...`
Expected: PASS

- [ ] **Step 7: Commit**

```bash
git add internal/observability/reporter.go internal/observability/reporter_test.go cmd/server/main.go
git commit -m "feat: metrics reporter for queue and redis health"
```

---

