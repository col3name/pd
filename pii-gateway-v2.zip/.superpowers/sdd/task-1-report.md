# Task 1 Report: Circuit breaker

## What I implemented

A simple circuit breaker in `internal/store/circuit.go` per the task brief. It opens after a configurable number of consecutive failures and stays open for a cooldown period, then allows a probe request.

API:
- `type Breaker struct`
- `func NewBreaker(failures int, cooldown time.Duration) *Breaker`
- `func (b *Breaker) Allow() bool` — true = call permitted
- `func (b *Breaker) Success()` — resets failure count
- `func (b *Breaker) Failure()` — increments failure count, opens breaker at threshold
- `func (b *Breaker) State() bool` — true = closed/up

Implementation is exactly the code from the brief. All methods are mutex-guarded for concurrency safety. `NewBreaker` guards against `failures <= 0` by defaulting to 1.

## What I tested and test results

Two tests from the brief in `internal/store/circuit_test.go`:
- `TestBreakerOpensAfterFailures` — verifies breaker opens after 3 failures.
- `TestBreakerRecoversAfterCooldown` — verifies breaker closes after cooldown and `Success()` restores state.

Focused run: `go test ./internal/store/ -run TestBreaker -v` → PASS (both tests).
Full package run: `go test ./internal/store/ -v` → PASS (all 9 tests, including pre-existing memory/store tests).
`go vet ./internal/store/` → clean.
`gofmt` → applied (fixed missing trailing newlines).

## TDD Evidence

**RED** — `go test ./internal/store/ -run TestBreaker -v`:
```
# github.com/kind-earthquake/pii-module/internal/store [github.com/kind-earthquake/pii-module/internal/store.test]
internal/store/circuit_test.go:11:7: undefined: NewBreaker
internal/store/circuit_test.go:22:7: undefined: NewBreaker
FAIL	github.com/kind-earthquake/pii-module/internal/store [build failed]
FAIL
```

**GREEN** — `go test ./internal/store/ -run TestBreaker -v`:
```
=== RUN   TestBreakerOpensAfterFailures
--- PASS: TestBreakerOpensAfterFailures (0.00s)
=== RUN   TestBreakerRecoversAfterCooldown
--- PASS: TestBreakerRecoversAfterCooldown (0.06s)
PASS
ok  	github.com/kind-earthquake/pii-module/internal/store	0.565s
```

## Files changed

- `internal/store/circuit.go` (new)
- `internal/store/circuit_test.go` (new)

## Self-review findings

- Implementation matches the brief verbatim.
- Concurrency-safe via `sync.Mutex` on all methods.
- `NewBreaker` handles `failures <= 0` defensively.
- Design note: after cooldown expires, `Allow()` returns true but `failures` is not reset until `Success()` is called — this is the intended probe-request pattern from the brief, not a bug.
- Fixed missing trailing newlines flagged by `gofmt`.

## Issues or concerns

None. Task complete.