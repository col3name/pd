package detector

import (
	"testing"

	"github.com/stretchr/testify/require"
)

func TestIsSurname(t *testing.T) {
	require.True(t, isSurname("Иванов"))
	require.True(t, isSurname("Петров"))
	require.True(t, isSurname("Сидорова"))
	require.True(t, isSurname("Ковальчук"))
	require.True(t, isSurname("Шевченко"))
	require.False(t, isSurname("Москва"))
	require.False(t, isSurname("Иван"))
}

func TestScoreConfidence(t *testing.T) {
	// base + dict + context = 1.0
	require.Equal(t, float32(1.0), scoreConfidence(0.5, true, 1, 0))
	// base + dict, no context = 0.8
	require.Equal(t, float32(0.8), scoreConfidence(0.5, true, 0, 0))
	// base + dict - negative = 0.5
	require.Equal(t, float32(0.5), scoreConfidence(0.5, true, 0, 1))
	// context capped at +0.4
	require.Equal(t, float32(1.0), scoreConfidence(0.5, true, 3, 0))
	// clamped to [0,1]
	require.Equal(t, float32(0.0), scoreConfidence(0.1, false, 0, 3))
}

func TestHasContext(t *testing.T) {
	text := "Клиент Иванов Иван Иванович"
	require.True(t, hasContext(text, 7, 30, contextKeywords(TypeFIO)))
	require.False(t, hasContext("Александр Пушкин написал", 0, 20, contextKeywords(TypeFIO)))
}

func TestHasNegativeContext(t *testing.T) {
	text := "Банк находится по адресу Москва, ул. Тверская, 10"
	require.True(t, hasNegativeContext(text, 0, len(text), negativeContext(TypeAddress)))
}

func TestDetectFIO(t *testing.T) {
	// Full name with context keyword → high confidence.
	spans := detectFIO("Клиент Иванов Иван Иванович")
	require.Len(t, spans, 1)
	require.Equal(t, TypeFIO, spans[0].Type)
	require.GreaterOrEqual(t, spans[0].Confidence, float32(0.95))
	// Span must cover the full FIO "Иванов Иван Иванович" (bytes [13, 51)).
	require.Equal(t, 13, spans[0].Start)
	require.Equal(t, 51, spans[0].End)

	// Name without context → low confidence (0.8), still returned.
	spans = detectFIO("Александр Пушкин написал")
	require.Len(t, spans, 1)
	require.Equal(t, float32(0.8), spans[0].Confidence)

	// No name → no span.
	spans = detectFIO("обычный текст без имён")
	require.Empty(t, spans)
}

func TestDetectAddress(t *testing.T) {
	// Client address with context → high confidence.
	spans := detectAddress("адрес клиента: г. Москва, ул. Ленина, д. 10")
	require.Len(t, spans, 1)
	require.Equal(t, TypeAddress, spans[0].Type)
	require.GreaterOrEqual(t, spans[0].Confidence, float32(0.95))
	// Span must cover the full address "Москва, ул. Ленина, д. 10" (bytes [31, 71)).
	require.Equal(t, 31, spans[0].Start)
	require.Equal(t, 71, spans[0].End)

	// Bank address with negative context → low confidence.
	spans = detectAddress("Банк находится по адресу Москва, ул. Тверская, 10")
	require.Len(t, spans, 1)
	require.Less(t, spans[0].Confidence, float32(0.75))

	// No city/street → no span.
	spans = detectAddress("обычный текст")
	require.Empty(t, spans)
}

func TestDetectAddressNotFIO(t *testing.T) {
	// A street name inside an address must be masked as АДРЕС, not ФИО.
	d := New(StructuredRules())
	spans := d.Detect("адрес клиента: г. Москва, ул. Ленина, д. 10")
	var hasAddress, hasFIO bool
	for _, s := range spans {
		switch s.Type {
		case TypeAddress:
			hasAddress = true
		case TypeFIO:
			hasFIO = true
		}
	}
	require.True(t, hasAddress, "expected address span, got %v", spans)
	require.False(t, hasFIO, "street name must not be masked as ФИО, got %v", spans)
}